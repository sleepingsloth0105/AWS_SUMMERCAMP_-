import json
import boto3
import pymysql

# AWS 서비스 클라이언트 생성
bedrock_client = boto3.client('bedrock-runtime')  # Bedrock 클라이언트
rds_host = 'db-ysu-006-campusdata.cdsomq8mgfd0.ap-south-1.rds.amazonaws.com'  # RDS 엔드포인트
db_username = 'admin'
db_password = 'password11!!'
db_name = 'CampDB'


def lambda_handler(event, context):
    try:
        """
        # 1. 클라이언트로부터 질문을 수신
        user_input = event['body']['user_input']
        print(f"Step 1: Received user input: {user_input}")
        
        # Lambda 함수 호출 성공 메시지를 즉시 반환
        initial_response = {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'Lambda function invoked successfully'
            }),
            'headers': {
                'Content-Type': 'application/json',
            },
        }
        return initial_response
        
        
        # 2. 사용자 정의 프롬프트 설정
        bedrock_prompt = f"I want you to summarize the given question as the form of [place: purpose]. Question: {user_input}"
        
        # 3. 아마존 Bedrock을 호출하여 질문을 요약
        bedrock_response = call_bedrock(bedrock_prompt)
        summarized_query = bedrock_response['summarized_query']  # 예시: "장소: 화장실"
        
        # 4. RDS에 쿼리 실행
        query_result = query_rds(summarized_query)
        
        # 5. 응답 생성
        response = {
            'statusCode': 200,
            'body': json.dumps({
                'query_result': query_result
            }),
            'headers': {
                'Content-Type': 'application/json',
            },
        }
        """
        
        return  {'statusCode': 200,'body' : '성공!' }
    
    except Exception as e:
        error_message = f"Error occurred: {str(e)}"
        print(error_message)
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)}),
            'headers': {
                'Content-Type': 'application/json',
            },
        }

def call_bedrock(prompt):
    try:
    # Bedrock에 프롬프트 전달하여 요약 요청
        response = bedrock_client.invoke_model(
            modelId='anthropic.claude-3-5-sonnet-20240620-v1:0',  # 사용할 Bedrock 모델 ID
            body=json.dumps({'input_text': prompt}),
            contentType='application/json',
        )
        response_body = json.loads(response['body'].read().decode('utf-8'))
        print(f"call_bedrock: Response body from Bedrock: {response_body}")
        return response_body
    except Exception as e:
        print(f"call_bedrock: Error occurred: {str(e)}")
        raise

def query_rds(summarized_query):
    try:
    # RDS에 연결
        connection = pymysql.connect(
            host='db-ysu-006-campusdata.cdsomq8mgfd0.ap-south-1.rds.amazonaws.com',
            user='admin',
            password='password11!!',
            database='CampDB',
            cursorclass=pymysql.cursors.DictCursor
        )
        print("query_rds: Connected to RDS successfully")
    
    
        with connection.cursor() as cursor:
            # 예시 쿼리, 실제 쿼리는 summarized_query에 맞춰 수정해야 합니다.
            sql = "SELECT 이름 FROM CampusProperty WHERE 용도도 = %식사%"
            cursor.execute(sql, (summarized_query,))
            result = cursor.fetchone()
            print(f"query_rds: Query executed successfully, result: {result}")
            return result
            
    except Exception as e:
        print(f"query_rds: Error occurred: {str(e)}")
        raise
        
    finally:
        connection.close()